import { createClient } from "@/lib/supabase/server"
import { AgentChat } from "@/components/agent/agent-chat"
import type { CVData } from "@/types/cv"

export default async function AgentPage() {
  const supabase = await createClient()
  
  // Get user's most recent CV for context
  const { data: cvs } = await supabase
    .from("cvs")
    .select("*")
    .order("updated_at", { ascending: false })
    .limit(1)

  const currentCV = cvs?.[0] as CVData | undefined

  return (
    <div className="h-[calc(100vh-0px)] flex flex-col">
      <AgentChat initialCV={currentCV} />
    </div>
  )
}
