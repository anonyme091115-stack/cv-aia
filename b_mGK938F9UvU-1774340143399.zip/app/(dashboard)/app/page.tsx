import { createClient } from "@/lib/supabase/server"
import { CVList } from "@/components/cv-list"
import { CreateCVButton } from "@/components/create-cv-button"
import type { CVData } from "@/types/cv"

export default async function DashboardPage() {
  const supabase = await createClient()
  
  const { data: cvs, error } = await supabase
    .from("cvs")
    .select("*")
    .order("updated_at", { ascending: false })

  if (error) {
    console.error("Error fetching CVs:", error)
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold font-[var(--font-display)]">
              Mes CVs
            </h1>
            <p className="text-muted-foreground mt-1">
              Créez et gérez vos CVs professionnels
            </p>
          </div>
          <CreateCVButton />
        </div>

        {/* CV List */}
        <CVList cvs={(cvs as CVData[]) || []} />
      </div>
    </div>
  )
}
