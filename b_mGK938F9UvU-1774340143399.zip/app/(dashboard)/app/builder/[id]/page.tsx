import { notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { CVEditor } from "@/components/builder/cv-editor"
import type { CVData } from "@/types/cv"

interface BuilderPageProps {
  params: Promise<{ id: string }>
}

export default async function BuilderPage({ params }: BuilderPageProps) {
  const { id } = await params
  const supabase = await createClient()

  const { data: cv, error } = await supabase
    .from("cvs")
    .select("*")
    .eq("id", id)
    .single()

  if (error || !cv) {
    notFound()
  }

  return <CVEditor initialCV={cv as CVData} />
}
