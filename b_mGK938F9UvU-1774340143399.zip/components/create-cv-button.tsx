"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import { Plus, Loader2 } from "lucide-react"
import { getDefaultSections } from "@/lib/cv-utils"

export function CreateCVButton() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleCreate() {
    setIsLoading(true)

    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        toast.error("Vous devez être connecté")
        return
      }

      const { data, error } = await supabase
        .from("cvs")
        .insert({
          user_id: user.id,
          title: "Mon nouveau CV",
          template: "minimal",
          sections: getDefaultSections(),
        })
        .select()
        .single()

      if (error) {
        toast.error("Erreur lors de la création du CV")
        console.error(error)
        return
      }

      toast.success("CV créé !")
      router.push(`/app/builder/${data.id}`)
    } catch {
      toast.error("Une erreur est survenue")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleCreate} disabled={isLoading}>
      {isLoading ? (
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
      ) : (
        <Plus className="mr-2 h-4 w-4" />
      )}
      Créer un CV
    </Button>
  )
}
