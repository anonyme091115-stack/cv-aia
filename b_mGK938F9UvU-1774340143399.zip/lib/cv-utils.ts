import type { CVSections } from "@/types/cv"

export function getDefaultSections(): CVSections {
  return {
    profile: {
      name: "",
      title: "",
      email: "",
      phone: "",
      location: "",
      linkedin: "",
      summary: "",
    },
    experiences: [],
    education: [],
    skills: [],
    languages: [],
    projects: [],
    certifications: [],
  }
}

export function generateShareId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  for (let i = 0; i < 10; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export function formatDateRange(startDate: string, endDate?: string | null, current?: boolean): string {
  const formatDate = (date: string) => {
    const d = new Date(date)
    return d.toLocaleDateString("fr-FR", { month: "short", year: "numeric" })
  }

  const start = formatDate(startDate)
  
  if (current) {
    return `${start} - Présent`
  }
  
  if (endDate) {
    return `${start} - ${formatDate(endDate)}`
  }
  
  return start
}

export function getATSScoreColor(score: number): string {
  if (score >= 80) return "text-green-500"
  if (score >= 60) return "text-yellow-500"
  return "text-red-500"
}

export function getATSScoreBadgeVariant(score: number): "default" | "secondary" | "destructive" {
  if (score >= 80) return "default"
  if (score >= 60) return "secondary"
  return "destructive"
}
